﻿using System.Linq.Expressions;

public class ProductFilter
{
    public string? Name { get; set; }
    public string? Category { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }  
    public bool? InStock { get; set; }

    public Expression<Func<Product, bool>> ToExpression()
    {
        var param = Expression.Parameter(typeof(Product), "p");

        Expression body = Expression.Constant(true);

        if (!string.IsNullOrWhiteSpace(Name))
        {
            var nameProp = Expression.Property(param, nameof(Product.Name));
            var contains = Expression.Call(nameProp, typeof(string).GetMethod("Contains", new[] { typeof(string) })!, Expression.Constant(Name));
            body = Expression.AndAlso(body, contains);
        }

        if (!string.IsNullOrWhiteSpace(Category))
        {
            var catProp = Expression.Property(param, nameof(Product.Category));
            var equals = Expression.Equal(catProp, Expression.Constant(Category));
            body = Expression.AndAlso(body, equals);
        }

        if (MinPrice.HasValue)
        {
            var priceProp = Expression.Property(param, nameof(Product.Price));
            var min = Expression.GreaterThanOrEqual(priceProp, Expression.Constant(MinPrice.Value));
            body = Expression.AndAlso(body, min);
        }

        if (MaxPrice.HasValue)
        {
            var priceProp = Expression.Property(param, nameof(Product.Price));
            var max = Expression.LessThanOrEqual(priceProp, Expression.Constant(MaxPrice.Value));
            body = Expression.AndAlso(body, max);
        }

        if (InStock.HasValue)
        {
            var inStockProp = Expression.Property(param, nameof(Product.InStock));
            var eq = Expression.Equal(inStockProp, Expression.Constant(InStock.Value));
            body = Expression.AndAlso(body, eq);
        }

        return Expression.Lambda<Func<Product, bool>>(body, param);
    }
}
