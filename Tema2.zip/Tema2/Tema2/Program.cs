﻿using System;
using System.Collections.Generic;
using System.Linq;

var products = new List<Product>
{
    new Product { Id = 1, Name = "Smartphone", Category = "Electronics", Price = 299.99m, InStock = true },
    new Product { Id = 2, Name = "Laptop", Category = "Electronics", Price = 999.50m, InStock = true },
    new Product { Id = 3, Name = "Desk Lamp", Category = "Home", Price = 45.00m, InStock = true },
    new Product { Id = 4, Name = "Headphones", Category = "Electronics", Price = 79.95m, InStock = false }
};

var filter = new ProductFilter
{
    Category = "Electronics",
    MinPrice = 100,
    InStock = true
};

var service = new ProductSearchService(products.AsQueryable());

var results = service.Search(
    filter,
    orderBy: p => p.Price,
    ascending: true,
    groupBy: p => (object)p.Category
);

// Print results
foreach (var p in results)
{
    Console.WriteLine($"{p.Id}: {p.Name} - {p.Category} - ${p.Price} - InStock: {p.InStock}");
}
