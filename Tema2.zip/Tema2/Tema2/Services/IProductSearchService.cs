﻿using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

public interface IProductSearchService
{
    IEnumerable<Product> Search(ProductFilter filter,
        Expression<Func<Product, object>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null);

    IEnumerable<Product> Search<TKey>(ProductFilter filter,
        Expression<Func<Product, TKey>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null);

    Task<IEnumerable<Product>> SearchAsync(ProductFilter filter,
        Expression<Func<Product, object>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null,
        CancellationToken cancellationToken = default);

    Task<IEnumerable<Product>> SearchAsync<TKey>(ProductFilter filter,
        Expression<Func<Product, TKey>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null,
        CancellationToken cancellationToken = default);
}
