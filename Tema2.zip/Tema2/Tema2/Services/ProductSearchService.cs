﻿using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

public class ProductSearchService : IProductSearchService
{
    private readonly IQueryable<Product> _products;

    public ProductSearchService(IQueryable<Product> products)
    {
        _products = products;
    }

    public IEnumerable<Product> Search(ProductFilter filter,
                                       Expression<Func<Product, object>>? orderBy = null,
                                       bool ascending = true,
                                       Expression<Func<Product, object>>? groupBy = null,
                                       int? skip = null,
                                       int? take = null)
    {
        return Search<object>(filter, orderBy == null ? null : (Expression<Func<Product, object>>)orderBy, ascending, groupBy, skip, take);
    }

    public Task<IEnumerable<Product>> SearchAsync(ProductFilter filter,
        Expression<Func<Product, object>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null,
        CancellationToken cancellationToken = default)
    {
        return SearchAsync<object>(filter, orderBy == null ? null : (Expression<Func<Product, object>>)orderBy, ascending, groupBy, skip, take, cancellationToken);
    }

    public IEnumerable<Product> Search<TKey>(ProductFilter filter,
        Expression<Func<Product, TKey>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null)
    {
        var query = _products;

        // Apply filter expression
        var expr = filter.ToExpression();
        query = query.Where(expr);

        // Ordering
        if (orderBy != null)
            query = ascending ? query.OrderBy(orderBy) : query.OrderByDescending(orderBy);

        // Grouping
        if (groupBy != null)
        {
            var grouped = query.GroupBy(groupBy).SelectMany(g => g);
            query = grouped;
        }

        // Pagination
        if (skip.HasValue)
            query = query.Skip(skip.Value);
        if (take.HasValue)
            query = query.Take(take.Value);

        return query.ToList();
    }

    public Task<IEnumerable<Product>> SearchAsync<TKey>(ProductFilter filter,
        Expression<Func<Product, TKey>>? orderBy = null,
        bool ascending = true,
        Expression<Func<Product, object>>? groupBy = null,
        int? skip = null,
        int? take = null,
        CancellationToken cancellationToken = default)
    {
        var result = Search<TKey>(filter, orderBy, ascending, groupBy, skip, take);
        return Task.FromResult(result);
    }
}
