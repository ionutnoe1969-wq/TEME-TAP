﻿public interface IPaymentProvider
{
    bool Charge(decimal amount);
}