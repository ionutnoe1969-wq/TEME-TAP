﻿public class Order
{
    public string Id { get; set; }
    public List<CartItem> Items { get; set; }
    public decimal Total { get; set; }
}