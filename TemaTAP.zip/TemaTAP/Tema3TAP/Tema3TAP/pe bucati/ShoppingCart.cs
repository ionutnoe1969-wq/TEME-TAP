﻿public class ShoppingCart
{
    private readonly List<CartItem> _items = new List<CartItem>();
    public IReadOnlyList<CartItem> Items => _items;

    public void AddProduct(Product product, int quantity)
    {
        if (product == null) throw new ArgumentNullException("product");
        if (quantity <= 0) quantity = 1;

        var existing = _items.FirstOrDefault(i => i.Product.Id == product.Id);
        if (existing != null)
            existing.Quantity += quantity;
        else
            _items.Add(new CartItem { Product = product, Quantity = quantity });
    }

    public decimal GetTotal()
    {
        return _items.Sum(i => i.GetTotal());
    }
}