﻿public class JsonOrderRepository : IOrderRepository
{
    private readonly string _filename;

    public JsonOrderRepository(string filename)
    {
        _filename = filename;
    }

    public void Save(Order order)
    {
        Console.WriteLine("Order saved (simulated). Id: " + (order?.Id ?? "(null)"));
    }
}