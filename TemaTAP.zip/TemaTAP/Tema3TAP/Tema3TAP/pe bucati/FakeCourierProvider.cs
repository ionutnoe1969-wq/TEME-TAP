﻿public class FakeCourierProvider : ICourierProvider
{
    public bool Ship(Order order)
    {
        Console.WriteLine("Order shipped (simulated). Id: " + (order?.Id ?? "(null)"));
        return true;
    }
}