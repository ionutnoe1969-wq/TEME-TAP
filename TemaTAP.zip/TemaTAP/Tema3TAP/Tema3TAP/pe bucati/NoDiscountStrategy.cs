﻿public class NoDiscountStrategy : IDiscountStrategy
{
    public decimal ApplyDiscount(decimal total) => total;
}