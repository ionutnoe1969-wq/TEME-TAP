﻿public class FakePaymentProvider : IPaymentProvider
{
    public bool Charge(decimal amount)
    {
        Console.WriteLine("Payment charged: " + amount);
        return true;
    }
}