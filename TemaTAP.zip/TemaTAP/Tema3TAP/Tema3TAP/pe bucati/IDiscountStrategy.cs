﻿public interface IDiscountStrategy
{
    decimal ApplyDiscount(decimal total);
}