﻿public class JsonProductRepository : IProductRepository
{
    private readonly List<Product> _products;

    public JsonProductRepository(string filename)
    {
        _products = new List<Product>
        {
            new Product { Id = "1", Name = "Apple", Price = 1.2m },
            new Product { Id = "2", Name = "Banana", Price = 0.8m },
            new Product { Id = "3", Name = "Coffee", Price = 5.5m }
        };
    }

    public IEnumerable<Product> GetProducts()
    {
        return _products;
    }

    public Product GetById(string id)
    {
        if (id == null) return null;
        return _products.FirstOrDefault(p => p.Id == id);
    }
}