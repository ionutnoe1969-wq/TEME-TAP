﻿public interface ICourierProvider
{
    bool Ship(Order order);
}