﻿public interface IProductRepository
{
    IEnumerable<Product> GetProducts();
    Product GetById(string id);
}