﻿public class CatalogService
{
    private readonly IProductRepository _repo;

    public CatalogService(IProductRepository repo)
    {
        _repo = repo;
    }

    public IEnumerable<Product> GetProducts()
    {
        return _repo.GetProducts();
    }
}