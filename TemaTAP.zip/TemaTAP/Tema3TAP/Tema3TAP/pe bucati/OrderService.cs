﻿public class OrderService
{
    private readonly IOrderRepository _orderRepo;
    private readonly IPaymentProvider _payment;
    private readonly ICourierProvider _courier;
    private readonly IDiscountStrategy _discount;

    public OrderService(IOrderRepository orderRepo, IPaymentProvider paymentProvider, ICourierProvider courierProvider, IDiscountStrategy discountStrategy)
    {
        _orderRepo = orderRepo;
        _payment = paymentProvider;
        _courier = courierProvider;
        _discount = discountStrategy;
    }

    public void PlaceOrder(ShoppingCart cart)
    {
        if (cart == null || cart.Items.Count == 0)
        {
            Console.WriteLine("Cart is empty.");
            return;
        }

        var total = cart.GetTotal();
        var discounted = _discount.ApplyDiscount(total);

        if (!_payment.Charge(discounted))
        {
            Console.WriteLine("Payment failed.");
            return;
        }

        var order = new Order
        {
            Id = Guid.NewGuid().ToString(),
            Items = new List<CartItem>(cart.Items as IEnumerable<CartItem> ?? new List<CartItem>()),
            Total = discounted
        };

        _orderRepo.Save(order);
        _courier.Ship(order);

        Console.WriteLine("Order placed successfully. Id: " + order.Id + " Total: " + order.Total);
    }
}