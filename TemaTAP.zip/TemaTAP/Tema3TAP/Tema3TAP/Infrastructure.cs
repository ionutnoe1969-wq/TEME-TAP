using System;
using System.Collections.Generic;
using System.Linq;


public class Product
{
    public string Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}

public class Order
{
    public string Id { get; set; }
    public List<CartItem> Items { get; set; }
    public decimal Total { get; set; }
}

public class CartItem
{
    public Product Product { get; set; }
    public int Quantity { get; set; }

    public decimal GetTotal()
    {
        return Product.Price * Quantity;
    }
}

public class ShoppingCart
{
    private readonly List<CartItem> _items = new List<CartItem>();
    public IReadOnlyList<CartItem> Items => _items;

    public void AddProduct(Product product, int quantity)
    {
        if (product == null) throw new ArgumentNullException("product");
        if (quantity <= 0) quantity = 1;

        var existing = _items.FirstOrDefault(i => i.Product.Id == product.Id);
        if (existing != null)
            existing.Quantity += quantity;
        else
            _items.Add(new CartItem { Product = product, Quantity = quantity });
    }

    public decimal GetTotal()
    {
        return _items.Sum(i => i.GetTotal());
    }
}

public interface IProductRepository
{
    IEnumerable<Product> GetProducts();
    Product GetById(string id);
}

public class JsonProductRepository : IProductRepository
{
    private readonly List<Product> _products;

    public JsonProductRepository(string filename)
    {
        _products = new List<Product>
        {
            new Product { Id = "1", Name = "Apple", Price = 1.2m },
            new Product { Id = "2", Name = "Banana", Price = 0.8m },
            new Product { Id = "3", Name = "Coffee", Price = 5.5m }
        };
    }

    public IEnumerable<Product> GetProducts()
    {
        return _products;
    }

    public Product GetById(string id)
    {
        if (id == null) return null;
        return _products.FirstOrDefault(p => p.Id == id);
    }
}

public interface IOrderRepository
{
    void Save(Order order);
}

public class JsonOrderRepository : IOrderRepository
{
    private readonly string _filename;

    public JsonOrderRepository(string filename)
    {
        _filename = filename;
    }

    public void Save(Order order)
    {
        Console.WriteLine("Order saved (simulated). Id: " + (order?.Id ?? "(null)"));
    }
}

public interface IPaymentProvider
{
    bool Charge(decimal amount);
}

public class FakePaymentProvider : IPaymentProvider
{
    public bool Charge(decimal amount)
    {
        Console.WriteLine("Payment charged: " + amount);
        return true;
    }
}

public interface ICourierProvider
{
    bool Ship(Order order);
}

public class FakeCourierProvider : ICourierProvider
{
    public bool Ship(Order order)
    {
        Console.WriteLine("Order shipped (simulated). Id: " + (order?.Id ?? "(null)"));
        return true;
    }
}

public interface IDiscountStrategy
{
    decimal ApplyDiscount(decimal total);
}

public class NoDiscountStrategy : IDiscountStrategy
{
    public decimal ApplyDiscount(decimal total) => total;
}

public class PercentageDiscountStrategy : IDiscountStrategy
{
    private readonly decimal _percentage;

    public PercentageDiscountStrategy(decimal percentage)
    {
        _percentage = percentage;
    }

    public decimal ApplyDiscount(decimal total)
    {
        return total - (total * _percentage);
    }
}

public class CatalogService
{
    private readonly IProductRepository _repo;

    public CatalogService(IProductRepository repo)
    {
        _repo = repo;
    }

    public IEnumerable<Product> GetProducts()
    {
        return _repo.GetProducts();
    }
}

public class OrderService
{
    private readonly IOrderRepository _orderRepo;
    private readonly IPaymentProvider _payment;
    private readonly ICourierProvider _courier;
    private readonly IDiscountStrategy _discount;

    public OrderService(IOrderRepository orderRepo, IPaymentProvider paymentProvider, ICourierProvider courierProvider, IDiscountStrategy discountStrategy)
    {
        _orderRepo = orderRepo;
        _payment = paymentProvider;
        _courier = courierProvider;
        _discount = discountStrategy;
    }

    public void PlaceOrder(ShoppingCart cart)
    {
        if (cart == null || cart.Items.Count == 0)
        {
            Console.WriteLine("Cart is empty.");
            return;
        }

        var total = cart.GetTotal();
        var discounted = _discount.ApplyDiscount(total);

        if (!_payment.Charge(discounted))
        {
            Console.WriteLine("Payment failed.");
            return;
        }

        var order = new Order
        {
            Id = Guid.NewGuid().ToString(),
            Items = new List<CartItem>(cart.Items as IEnumerable<CartItem> ?? new List<CartItem>()),
            Total = discounted
        };

        _orderRepo.Save(order);
        _courier.Ship(order);

        Console.WriteLine("Order placed successfully. Id: " + order.Id + " Total: " + order.Total);
    }
}
