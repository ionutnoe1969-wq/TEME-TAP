﻿using System;

class Program
{
    static void Main()
    {
        // Infrastructure
        IProductRepository productRepo = new JsonProductRepository("products.json");
        IOrderRepository orderRepo = new JsonOrderRepository("orders.json");
        IPaymentProvider paymentProvider = new FakePaymentProvider();
        ICourierProvider courierProvider = new FakeCourierProvider();
        IDiscountStrategy discountStrategy = new NoDiscountStrategy();

        // Services
        var catalogService = new CatalogService(productRepo);
        var orderService = new OrderService(orderRepo, paymentProvider, courierProvider, discountStrategy);

        var cart = new ShoppingCart();
        var culture = new System.Globalization.CultureInfo("ro-RO");

        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("=====================================");
            Console.WriteLine("           SIMPLE SHOP MENU           ");
            Console.WriteLine("=====================================");
            Console.WriteLine("1. List products");
            Console.WriteLine("2. Add to cart");
            Console.WriteLine("3. View cart");
            Console.WriteLine("4. Place order");
            Console.WriteLine("0. Exit");
            Console.WriteLine();

            var choice = Console.ReadLine();
            if (choice == "0") break;

            switch (choice)
            {
                case "1":
                    Console.WriteLine();
                    Console.WriteLine("Available products:");
                    Console.WriteLine("{0,-5} {1,-25} {2,10}", "Id", "Name", "Price");
                    Console.WriteLine(new string('-', 45));
                    foreach (var p in catalogService.GetProducts())
                        Console.WriteLine("{0,-5} {1,-25} {2,10}", p.Id, p.Name, p.Price.ToString("C", culture));
                    break;

                case "2":
                    Console.Write("Product Id: ");
                    var id = Console.ReadLine();
                    Console.Write("Quantity: ");
                    int qty;
                    var qtyInput = Console.ReadLine();
                    if (!int.TryParse(qtyInput, out qty) || qty <= 0) qty = 1;
                    var product = productRepo.GetById(id);
                    if (product is null)
                    {
                        Console.WriteLine("Product not found.");
                    }
                    else
                    {
                        cart.AddProduct(product, qty);
                        Console.WriteLine();
                        Console.WriteLine("Added to cart:");
                        Console.WriteLine("{0} x {1}  ->  {2}", product.Name, qty, (product.Price * qty).ToString("C", culture));
                    }
                    break;

                case "3":
                    Console.WriteLine();
                    Console.WriteLine("Your cart:");
                    if (cart.Items.Count == 0)
                    {
                        Console.WriteLine("(empty)");
                    }
                    else
                    {
                        Console.WriteLine("{0,-25} {1,5} {2,12} {3,14}", "Product", "Qty", "Price", "Line Total");
                        Console.WriteLine(new string('-', 60));
                        foreach (var item in cart.Items)
                        {
                            Console.WriteLine("{0,-25} {1,5} {2,12} {3,14}", item.Product.Name, item.Quantity, item.Product.Price.ToString("C", culture), item.GetTotal().ToString("C", culture));
                        }
                        Console.WriteLine(new string('-', 60));
                        Console.WriteLine("{0,45} {1,14}", "Total:", cart.GetTotal().ToString("C", culture));
                    }
                    break;

                case "4":
                    orderService.PlaceOrder(cart);
                    break;
            }
        }
    }
}
